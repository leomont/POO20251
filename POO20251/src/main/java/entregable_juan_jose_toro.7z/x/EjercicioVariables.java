package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        int numeroA = 89;
        int numeroB = 323;



        // Mostrar en pantalla los numeros A y B
        System.out.println(numeroA);
        System.out.println(numeroB);



        //  Operaciones aritmeticas
        System.out.println(numeroA + numeroB);
        System.out.println(numeroA - numeroB);
        System.out.println(numeroA * numeroB);
        System.out.println(numeroA / numeroB);


        }
    }
