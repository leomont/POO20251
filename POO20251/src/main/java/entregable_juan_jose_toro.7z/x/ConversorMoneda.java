package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        // Cantidad en pesos Colombianos

        double Pesos = 200000;

        // Tasa de cambio
        double ValorDolar = 3.8950;

        double dolares;
        dolares = Pesos / ValorDolar;

        System.out.println("Pesos equivalentes = " + Pesos);
        System.out.println("Valor dolar equivalentes =  " + ValorDolar);
        System.out.println("Dolares equivalentes = " + dolares);

    }
}


