package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        // Variable
        int num = 0;

        // Ciclo while
        while (num <=100){
            if (num % 8 == 0){ // si es multiplo e 8

                System.out.println(num+ " Es multiplo de 8");
            }
            num++;

        }


    }
}

