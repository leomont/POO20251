package org.example;

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el numero entero 1 de hasta 5 ");
        int numero=sc.nextInt();

        if (numero >= -99999 && numero <= 99999) {

            int numeroA = Math.abs(numero);
            int numeroB = numeroA;

            while (numeroB >= 10){

            numeroB /= 10 ; }

            System.out.println("La primera cifra es "+ numeroB);

            }else {
        System.out.println("ERROR coloca un número maximo de 5 dijitos");

        }
    }
}