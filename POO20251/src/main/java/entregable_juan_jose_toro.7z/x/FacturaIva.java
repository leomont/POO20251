package org.example;
import java.util.Scanner;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce la base de la factura ");
        double base = sc.nextDouble();

        double iva  = base*0.19; // IVA del 19%
        double total = base + iva;


        System.out.println("Base : " + base );
        System.out.println("Iva : " + iva );
        System.out.println("Total : " + total );

        sc.close();
    }
}